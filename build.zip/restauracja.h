#ifndef RESTAURACJA_H
#define RESTAURACJA_H

// ====== INKLUDY ======
#include "common.h"

// Header dla modułu programu głównego (restauracja.c).

#endif // RESTAURACJA_H
